package com.exceptions;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public class NoSuchPathException extends Exception {

    public String getMessage(){
        return "INVALID PATH";
    }

}
