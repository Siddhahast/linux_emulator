package com;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public class Driver {

    public static void main(String[] args) throws Exception{
        NodeSystem system = NodeSystem.getSystem();
        ShellPrompt prompt = new ShellPrompt(system, system.getRoot());

        CommandController controller = new CommandController(prompt);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        for (;;){
            String commandInput = br.readLine();
            controller.processCommand(commandInput);
        }

    }

}
