package com;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public class Directory {

    String directoryName;

    public Directory(String directoryName){
        this.directoryName = directoryName;
    }

    public String getFileName(){
        return directoryName;
    }

    public void setFileName(String fileName){
        this.directoryName = fileName;
    }

}
