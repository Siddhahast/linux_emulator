package com;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public class NodeSystem {

    private int V;
    private Node root;

    private static NodeSystem system = new NodeSystem();

    public static NodeSystem getSystem(){
        return system;
    }

    private NodeSystem(){
        root = new Node("/");
    }

    public Node getRoot(){
        return root;
    }


}
