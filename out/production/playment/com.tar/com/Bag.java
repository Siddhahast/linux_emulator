package com;

import java.util.ArrayList;
import java.util.*;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public class Bag {

    Set<Node> adj;

    public Bag(){
        adj = new HashSet<Node>();
    }

    public Set<Node> adj(){
        return adj;
    }

    public void add(Node node){
        adj.add(node);
    }

}
