package com;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public class CommandController {

    private ShellPrompt shellPrompt;
    public CommandController(ShellPrompt shellPrompt){
        this.shellPrompt = shellPrompt;
    }

    public void processCommand(String input){

        String[] coms = input.split(" ");
        String command = coms[0];
        String[] files = null;
        try{
            files = coms[1].split("/");
            callUpon(command, files);
        } catch (ArrayIndexOutOfBoundsException ex){
            callUpon(command, null);
        }


    }

    public void callUpon(String command, String[] files){

        if(command.equalsIgnoreCase("cd")){
            shellPrompt.changeDirectory(files);
        } else if(command.equalsIgnoreCase("mkdir")){
            shellPrompt.makeDir(files);
        } else if(command.equalsIgnoreCase("pwd")){
            System.out.println(shellPrompt.presentDirectory());
        } else if(command.equalsIgnoreCase("rm")){
            shellPrompt.removeDirectory(files);
        } else if(command.equalsIgnoreCase("ls")){
            shellPrompt.getfiles();
        }
        else{
            System.out.println("No such commands");
        }
    }

}
