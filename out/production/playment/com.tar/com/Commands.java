package com;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public enum Commands {
    cd, pwd
}
