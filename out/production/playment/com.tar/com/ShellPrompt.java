package com;

import com.exceptions.DirectoryAlreadyExistException;
import com.exceptions.NoSuchPathException;

import java.util.*;

/**
 * Created by siddhahastmohapatra on 17/01/17.
 */
public class ShellPrompt {

    private NodeSystem nodeSystem;
    private Node node;
    private Stack<String> stack;
    private NodePath path;

    public ShellPrompt(NodeSystem system, Node node){
        this.nodeSystem = system;
        this.node = node;
        this.path = new NodePath(system.getRoot(), system);
        this.stack = new Stack<>();
    }

    public void addFolder(String fileName){
        NodeDAO dao = new NodeDAO(node);
        dao.addNode(fileName);
    }

    public void makeDir(String[] files){
        String makeFile = null;
        Queue<String> fileQ = new LinkedList<String>();
        for(int i = 0;i<files.length;i++){
            if(i==files.length-1){
                makeFile = files[i];
            } else{
                fileQ.add(files[i]);
            }
        }
        boolean allowLoopBack = true;
        path = new NodePath(node, nodeSystem);
        Stack<String> newStack = new Stack<String>();
        Node t = path.traversePath(allowLoopBack, fileQ, newStack);
        if(t==null){
            //No such directory exist
            System.out.print(new NoSuchPathException().getMessage());
        } else{

            if(t.getFolders().get(makeFile)==null){
                t.getFolders().put(makeFile, new Node(makeFile));
                //Success
                System.out.println("SUCCESS");
            } else{
                //Already exist
                System.out.print(new DirectoryAlreadyExistException().getMessage());
            }
        }
    }

    public void changeDirectory(String[] files){
        Queue<String> fileQ = new LinkedList<String>();
        for(int i = 0;i<files.length;i++){
            fileQ.add(files[i]);
        }
        Stack<String> newStack = new Stack<String>();
        Node t = path.traversePath(false, fileQ, newStack);
        if(t==null){
            //No such directory
            System.out.print(new NoSuchPathException().getMessage());
        } else{
            node = t;
            stack = newStack;
            System.out.println("SUCCESS");
        }
    }

    public String presentDirectory(){
        Stack<String> copyStack = new Stack<String>();

        while (!stack.isEmpty()){
            copyStack.push(stack.pop());
        }

        StringBuffer sb = new StringBuffer();
        while(!copyStack.isEmpty()){
            String s = copyStack.pop();
            sb.append("/"+s);
            stack.push(s);
        }
        return new String(sb);
    }

    public void removeDirectory(String[] files){
        String makeFile = null;
        Queue<String> fileQ = new LinkedList<String>();
        for(int i = 0;i<files.length;i++){
            if(i==files.length-1){
                makeFile = files[i];
            } else{
                fileQ.add(files[i]);
            }
        }
        boolean allowLoopBack = true;
        path = new NodePath(node, nodeSystem);
        Stack<String> newStack = new Stack<String>();
        Node t = path.traversePath(allowLoopBack, fileQ, newStack);
        if(t==null){
            //No such directory exist
            System.out.print(new NoSuchPathException().getMessage());
        } else{

            if(t.getFolders().get(makeFile)!=null){
                t.getFolders().remove(makeFile);
                //Success
                System.out.println("SUCCESS");
            } else{
                //Already exist
                System.out.print(new DirectoryAlreadyExistException().getMessage());
            }
        }
    }

    public void getfiles(){
        Map<String, Node> map = node.getFolders();
        for(Map.Entry<String, Node> entry: map.entrySet()){
            System.out.println(entry.getKey());
        }

    }
}
